class mathDotMaxOfExample
{
	public static void main(String arg[])
	{
		int x=60;
		int y=40;
		System.out.println(Math.max(x,y));
	}
}