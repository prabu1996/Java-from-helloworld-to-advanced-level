class mathDotPowOfExample
{
	public static void main(String arg[])
	{
		int x=2;
		System.out.println(Math.pow(x,3));
	}
}