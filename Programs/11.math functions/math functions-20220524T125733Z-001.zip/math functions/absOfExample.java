import java.lang.*;
class absOfExample
{
	public static void main(String arg[])
	{
		int x=78;
		int y=-56;
		System.out.println(Math.abs(x));
		System.out.println(Math.abs(y));
		System.out.println(Math.abs(Integer.MIN_VALUE));
	}
}