class mathDotMinOfExample
{
	public static void main(String arg[])
	{
		int x,y;
		x=50;
		y=10;
		System.out.println(Math.min(x,y));
	}
}