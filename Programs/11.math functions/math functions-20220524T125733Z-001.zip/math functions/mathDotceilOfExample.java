class mathDotceilOfExample
{
	public static void main(String arg[])
	{
		double a,b,c,d,e,f,g,h;
		a=83.56;
		b=-83.56;
		c=0.0;
		d=-0.0;
		e=1.0/0;
		f=-1.0/0;
		g=-1.25;
		h=0.25;
		System.out.println(Math.ceil(a));
		System.out.println(Math.ceil(b));
		System.out.println(Math.ceil(c));
		System.out.println(Math.ceil(d));
		System.out.println(Math.ceil(e));
		System.out.println(Math.ceil(f));
		System.out.println(Math.ceil(g));
		System.out.println(Math.ceil(h));
	}
}