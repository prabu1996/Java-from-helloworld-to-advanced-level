class mathDotRandomOfExampple
{
	public static void main(String arg[])
	{
		double a=Math.random();
		System.out.println(a);
	}
}