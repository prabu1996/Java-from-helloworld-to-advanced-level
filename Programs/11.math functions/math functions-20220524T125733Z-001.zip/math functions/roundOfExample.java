class roundOfExample
{
	public static void main(String arg[])
	{
		double x=55.738;
		System.out.println(Math.round(x));
	}
}