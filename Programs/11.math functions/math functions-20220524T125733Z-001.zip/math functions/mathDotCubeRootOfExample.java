class mathDotCubeRootOfExample
{
	public static void main(String arg[])
	{
		int x=27;
		System.out.println(Math.cbrt(x));
	}
}