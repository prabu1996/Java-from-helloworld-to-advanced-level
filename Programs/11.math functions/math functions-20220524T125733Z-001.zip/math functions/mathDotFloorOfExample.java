class mathDotFloorOfExample
{
	public static void main(String arg[])
	{
		double a,b,c,d,e,f,g,h;
		a=83.56;
		b=-83.56;
		c=0.0;
		d=-0.0;
		e=1.0/0;
		f=-1.0/0;
		g=-1.25;
		h=0.25;
		System.out.println(Math.floor(a));
		System.out.println(Math.floor(b));
		System.out.println(Math.floor(c));
		System.out.println(Math.floor(d));
		System.out.println(Math.floor(e));
		System.out.println(Math.floor(f));
		System.out.println(Math.floor(g));
		System.out.println(Math.floor(h));
	}
}