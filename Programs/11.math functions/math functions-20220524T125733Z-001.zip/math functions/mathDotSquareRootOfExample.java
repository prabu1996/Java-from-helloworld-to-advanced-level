class mathDotSquareRootOfExample
{
	public static void main(String arg[])
	{
		int x=4;
		System.out.println(Math.sqrt(x));
	}
}