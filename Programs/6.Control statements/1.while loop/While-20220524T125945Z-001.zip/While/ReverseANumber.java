import java.io.*;
class ReverseANumber
{
	public static ovid main(String arg[])
	{
		try
		{
			DataInputStream t=new DataInputStream(System.in);
			int n,i,z;
			System.out.println("number=");
			n=Integer.parseInt(t.readLine());
			i=1;
			while(i<n+1)
		}	
		catch(Exception e)
		{
			System.out.println(e);
		}
	}
}