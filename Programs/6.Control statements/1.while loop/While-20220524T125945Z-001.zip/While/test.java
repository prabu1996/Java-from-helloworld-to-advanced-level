class test
{
	public static void main(String arg[])
	{
		int a=5;
		String b;
		b="";
		int c=10;
		System.out.println(a+c);
	}
}