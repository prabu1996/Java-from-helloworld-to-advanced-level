class TestIntConcString
{
	public static void main(String arg[])
	{
		int a=5;
		String b="";
		System.out.println(a+b);
	}
}