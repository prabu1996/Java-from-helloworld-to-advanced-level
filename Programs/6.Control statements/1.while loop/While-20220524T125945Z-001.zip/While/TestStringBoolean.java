class TestStringBoolean
{
	public static void main(String arg[])
	{
		String a="prabu";
		String b="prabu";
		if(a==b)
			System.out.println("same");
	}
}