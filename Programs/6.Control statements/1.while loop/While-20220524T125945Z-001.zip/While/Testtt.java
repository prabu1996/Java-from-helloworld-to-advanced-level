class Testtt
{
	public static void main(String arg[])
	{
		int a=2;
		String b="1";
		System.out.println(a+b);
	}
}