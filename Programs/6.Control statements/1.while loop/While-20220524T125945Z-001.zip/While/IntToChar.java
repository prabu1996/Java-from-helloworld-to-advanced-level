class IntToChar
{
	public static void main(String arg[])
	{
		int a='12';
		char b=(char) a;
		System.out.println(b);
	}
}