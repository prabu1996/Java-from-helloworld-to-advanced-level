import java.util.*;
class SubClass
{
	int input,i,n,a;
	String x;
	String rev="";
	public void function()
	{
		
		for(i=0;i<n;i++)
		{
			a=input%10;
			rev+=a;
			input/=10;
		}
	}
	public void getInput()
	{
		Scanner t=new Scanner(System.in);
		System.out.println("Enter a");
		input=t.nextInt();
		x=String.valueOf(input);
		n=x.length();
		function();
	}
	public void display()
	{
		getInput();	
		System.out.println("reversed input="+rev);
		
	}
}
class MainClassReverseANumber1
{
	public static void main(String arg[])
	{
		SubClass m=new SubClass();
		m.display();
	}
}