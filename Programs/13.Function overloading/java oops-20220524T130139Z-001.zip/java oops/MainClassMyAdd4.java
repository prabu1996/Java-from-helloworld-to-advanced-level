import java.util.*;
class SubClass
{
	public int function(int x,int y)
	{
		int z=x+y;
		return z;
	}
	public void display()
	{
		Scanner t=new Scanner(System.in);
		System.out.println("Enter a");
		int a=t.nextInt();
		System.out.println("Enter b");
		int b=t.nextInt();
		System.out.println("Sum of a&b is="+function(a,b));	
	}
}
class MainClassMyAdd4
{
	public static void main(String arg[])
	{
		SubClass m=new SubClass();
		m.display();	
	}
}
