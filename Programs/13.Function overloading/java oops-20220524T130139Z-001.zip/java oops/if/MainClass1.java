import java.util.*;
class SubClass
{
	int a,b,x;
	public void function()
	{
		getInput();
		if(a>b)
			System.out.println("biggest num is a="+a);
		if(b>a)
			System.out.println("biggest num is b="+b);
		if(a==b)
			System.out.println("both a&b are equal");
	}
	public void getInput()
	{
		Scanner t=new Scanner(System.in);
		System.out.println("enter a");
		a=t.nextInt();
		System.out.println("Enter b");
		b=t.nextInt();
	}
}
class MainClass1
{
	public static void main(String arg[])
	{
		SubClass m=new SubClass();
		m.function();
	}
}