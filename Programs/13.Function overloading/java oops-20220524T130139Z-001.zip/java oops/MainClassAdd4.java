import java.util.*;
class SubClass
{
	
	public int function(int x,int y)
	{
		int a,b,c;
		a=x;	
		b=y;
		c=a+b;
		return c;
	}
}
class MainClassAdd4
{
	public static void main(String arg[])
	{
		Scanner t=new Scanner(System.in);
		System.out.println("Enter a");
		int a=t.nextInt();
		System.out.println("Enter b");
		int b=t.nextInt();
		SubClass m=new SubClass();
		int z=m.function(a,b);
		System.out.println("sum of a&b is="+z);
	}
}