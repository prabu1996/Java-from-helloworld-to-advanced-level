import java.util.*;
class SubClass
{
	int a,b,c,x;
	public void function()
	{
		x=a;
		a=b;
		b=c;
		c=x;
	}
	public void getInput()
	{
		Scanner t=new Scanner(System.in);
		System.out.println("Enter a");
		a=t.nextInt();
		System.out.println("Enter b");
		b=t.nextInt();
		System.out.println("Enter c");
		c=t.nextInt();
		function();
	}
	public void display()
	{
		getInput();
		System.out.println("a="+a);
		System.out.println("b="+b);
		System.out.println("c="+c);
	}
}
class MainClassSwap1
{
	public static void main(String arg[])
	{
		SubClass m=new SubClass();
		m.display();
	}
}