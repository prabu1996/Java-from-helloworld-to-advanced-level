import java.lang.*;
class compareToOf
{
	public static void main(String arg[])
	{
		String s1,s2,s3,s4,s5,s6;
		s1="hello";
		s2="hello";
		s3="meklo";
		s4="hemlo";
		s5="flag";
		s6="";
		s7="me";
		System.out.println(s1.compareTo(s2));
		System.out.println(s1.compareTo(s3));
		System.out.println(s1.compareTo(s4));
		System.out.println(s1.compareTo(s5));
		System.out.println(s1.compareTo(s6));
		System.out.println(s6.compareTo(s7));
	}
}