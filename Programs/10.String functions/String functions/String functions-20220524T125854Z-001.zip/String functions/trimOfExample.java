import java.lang.*;
public class trimOfExample
{
	public static void main(String arg[])
	{
		String name="   prabu    ";
		String name1=name.trim();
		System.out.println(name);
		System.out.println(name1);
	}
}