import java.lang.*;
public class CharAtExample
{
	public static void main(String arg[])
	{
		String name;
		name="prabu a";
		System.out.println(name.charAt(4));
	}
}