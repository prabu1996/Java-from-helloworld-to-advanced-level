import java.io.*;
class reverseOfExample
{
	public static void main(String arg[])
	{
		StringBuffer t=new StringBuffer("madam");
		StringBuffer s=new StringBuffer("GeeksforGeeks");
		System.out.println(t.reverse());
		System.out.println(s.reverse());
	}
}