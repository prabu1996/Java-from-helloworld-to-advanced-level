import java.io.*;
class appendOfExample
{
	public static void main(String arg[])
	{
		StringBuffer t=new StringBuffer("Geeksfor");
		System.out.println(t.append("geeks"));
		System.out.println(t.append(12));
		
	}
}