import java.io.*;
class lengthOfExa
{
	public static void main(String arg[])
	{
		StringBuffer t=new StringBuffer("GeekssforGeeks");
		System.out.println(t.length());
		System.out.println(t.capacity());
	}
}