import java.io.*;
class replaceOfExample
{
	public static void main(String arg[])
	{
		StringBuffer t=new StringBuffer("GeeksforGeeks");
		System.out.println(t.replace(5,8,"are"));
	}
}