import java.lang.*;
public class endsWithExample
{
	public static void main(String arg[])
	{
		String name="prabu ayyappan";
		System.out.println(name.endsWith("n"));
		System.out.println(name.endsWith("ayyappan"));
		System.out.println(name.endsWith("bpa"));
		System.out.println(name.endsWith("prabu"));
	}	
}