import java.lang.*;
public class joinOfExample1
{
	public static void main(String arg[])
	{
		String name;
		name=String.join("vs","mumbai "," csk "," delhi");
		System.out.println(name);
	}
}