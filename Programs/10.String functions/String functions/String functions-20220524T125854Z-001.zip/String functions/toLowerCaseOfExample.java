import java.lang.*;
public class toLowerCaseOfExample
{
	public static void main(String arg[])
	{
		String name="PRABU";
		String name1=name.toLowerCase();
		System.out.println(name1);	
	}	
}