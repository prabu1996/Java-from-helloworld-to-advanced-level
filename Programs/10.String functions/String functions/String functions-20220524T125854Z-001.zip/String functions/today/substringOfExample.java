import java.lang.*;
public class substringOfExample
{
	public static void main(String arg[])
	{
		String s1;
		s1="prabu ayyappan";
		System.out.println(s1.substring(2));
		System.out.println(s1.substring(1,5));
		System.out.println(s1.substring(1,15));
		
	}
}