import java.lang.*;
public class concatExample
{
	public static void main(String arg[])
	{
		String a,b,c;
		a="prabu";
		b="ayyappan";
		c="pushpam";
		System.out.println(a.concat(b).concat(c));
	}
}