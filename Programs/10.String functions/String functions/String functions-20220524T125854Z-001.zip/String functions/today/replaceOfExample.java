import java.lang.*;
public class replaceOfExample
{
	public static void main(String arg[])
	{
		String s1,s2;
		s1="prabu ayyappan";
		s2="my name is prabu";
		System.out.println(s1.replace("p","b"));
		System.out.println(s2.replace("prabu","abhi"));
		System.out.println(s2.replace(" ",""));
		
	}
}