import java.lang.*;
public class lastIndexOfExample
{
	public static void main(String arg[])
	{
		String s1;
		s1="prabu ayyappan";
		System.out.println(s1.indexOf("p"));
		System.out.println(s1.lastIndexOf("p"));
	}
}