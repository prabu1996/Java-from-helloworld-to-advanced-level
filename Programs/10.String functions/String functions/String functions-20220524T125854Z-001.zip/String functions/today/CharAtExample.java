import java.lang.*;
public class CharAtExample
{
	public static void main(String arg[])
	{
		String name;
		name="javatpoint";
		System.out.println(name.charAt(4));
	}
}