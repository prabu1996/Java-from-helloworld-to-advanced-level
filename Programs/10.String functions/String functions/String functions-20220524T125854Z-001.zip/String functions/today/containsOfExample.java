import java.io.*;
public class containsOfExample
{
	public static void main(String arg[])
	{
		String name;
		name="prabu";
		System.out.println(name.contains("P"));
		System.out.println(name.contains("p"));
	}
}