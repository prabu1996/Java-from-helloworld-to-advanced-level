import java.lang.*;
public class EndsWithOfExample
{
	public static void main(String arg[])
	{
		String name;
		name="prabu ayyappan";
		System.out.println(name.endsWith("u"));
		System.out.println(name.endsWith("n"));
		System.out.println(name.endsWith("ayyappan"));
	}
}