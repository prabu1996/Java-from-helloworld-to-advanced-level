import java.lang.*;
public class toUpperCaseOfExample
{
	public static void main(String arg[])
	{
		String name="prabu";
		String name1=name.toUpperCase();
		System.out.println(name1);	
	}	
}