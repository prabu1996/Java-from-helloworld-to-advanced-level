import java.lang.*;
public class isEmptyExample
{
	public static void main(String arg[])
	{
		String x,y;
		x="";
		y="prabu";
		System.out.println(x.isEmpty());
		System.out.println(y.isEmpty());
		
	}
}