import java.lang.*;
public class startsWithOfExample1
{
	public static void main(String arg[])
	{
		String s1="java string split method by javapoint";
		System.out.println(s1.startsWith("ja"));
		System.out.println(s1.startsWith("java string"));
		System.out.println(s1.startsWith("va"));
	}
}