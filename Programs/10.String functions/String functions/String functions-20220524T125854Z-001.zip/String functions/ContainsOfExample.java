import java.lang.*;
public class ContainsOfExample
{
	public static void main(String arg[])
	{
		String name;
		name="prabu is super hero";
		System.out.println(name.contains("prabu"));
		System.out.println(name.contains("prabu  is"));
		System.out.println(name.contains("prabu is"));
		System.out.println(name.contains("suber"));	
	}
}