import java.lang.*;
public class lengthOfExa
{
	public static void main(String arg[])
	{
		String name="prabu a";
		System.out.println(name.length());
	}
}