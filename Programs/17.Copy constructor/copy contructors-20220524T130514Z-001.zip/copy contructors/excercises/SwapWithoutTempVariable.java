import java.util.*;
class SubClass
{
	int a,b;
	public SubClass(int a,int b)
	{
		this.a=a;
		this.b=b;
	}
	public SubClass(SubClass t4)
	{
		this.a=t4.a;
		this.b=t4.b;	
	}
	public void swap()
	{
		a=a+b;
		b=a-b;
		a=a-b;		
	}
	public void display()
	{
		System.out.println("a="+a);
		System.out.println("b="+b);
	}
}
class SwapWithoutTempVariable
{
	public static void main(String arg[])
	{
		Scanner t1=new Scanner(System.in);
		System.out.println("Enter a ,b");
		int a=t1.nextInt();
		int b=t1.nextInt();
		SubClass t2=new SubClass(a,b);
		SubClass t3=new SubClass(t2);
		t3.swap();
		t3.display();
	}
}