class I
{
	int a,b,u;
	public I()
	{

	}
	public I(int a,int b)	
	{
		this.a=a;
		this.b=b;
		System.out.println("a="+a);
		System.out.println("b="+b);
	}
	public I(I object)
	{
		this.a=(object.a)*2;
		this.b=(object.b)*2;
		System.out.println("a="+a);
		System.out.println("b="+b);
		Add2();
		
	}
	public I(I yy,int u)
	{
		this.a=yy.a;
		this.b=yy.b;
		this.u=u;
		Mult1();		
	}
	public int Add()
	{
		int c=a+b;
		return c;
	}
	public void Add2()
	{
		int c=a+b;
		System.out.println("a+b of copy consrucor="+c);	
	}
	public void Mult1()
	{
		System.out.println("a="+a);
		System.out.println("b="+b);
		System.out.println("u="+u);
	}		
}
class Arithmetic
{
	public static void main(String arg[])
	{
		I x=new I();
		I y=new I(10,20);
		I z=new I(y);//y is object
		System.out.println("a+b="+x.Add()); //a+b=0
		System.out.println("a+b="+y.Add());
		I xx=new I(y,10);	
		//System.out.println("multi of before squaring of a&b="+xx.Mult1());
	}
}