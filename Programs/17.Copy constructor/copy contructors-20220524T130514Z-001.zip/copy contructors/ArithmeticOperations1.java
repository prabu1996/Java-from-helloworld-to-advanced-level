class I
{
	int a,b;
	public I()
	{
		
	}
	public I(int a,int b)
	{
		this.a=a;
		this.b=b;	
	}
	public I(I obj)
	{
		int a=(obj.a)*2;
		int b=(obj.b)*2;
		Subtraction();		
	}
	public I(I c)
	{

	}
	public int Addition()
	{
		int c=a+b;
		return c;	
	}
	public void Subtraction()
	{
		int c=	
	} 
	public void Multiplication()
	{

	}
	public void Division()
	{

	}	
}
class ArithmeticOperations1
{
	public static void main(String arg[])
	{
		I v1=new I();
		I v2=new I(10,20); //addition
		I v3=new I(v2);
		System.out.println("a+b="+Addition());
	}	
}